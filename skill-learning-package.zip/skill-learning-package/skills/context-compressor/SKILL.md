---
name: Context Compressor
slug: context-compressor
version: 1.0.0
description: "9-segment structured context compression for OpenClaw. Intelligently summarizes conversations and memory while preserving critical technical details."
metadata:
  openclaw:
    requires:
      bins: []
    os: ["linux", "darwin", "win32"]
    configPaths: ["./MEMORY.md", "./memory/", "./AGENTS.md"]
---

# Context Compressor - Intelligent Context Management for OpenClaw

Advanced context compression system that preserves essential information while reducing token usage and improving performance.

## When to Use

- When conversations become long and unwieldy
- Before starting new major tasks to clear context
- Periodically during long sessions
- When memory files grow too large
- To create concise summaries for sharing or review

## The 9-Segment Structure

Inspired by Claude Code's proven approach, OpenClaw's context compressor uses a 9-segment structure:

### 1. Primary Request and Intent
- User's main goals and objectives
- Explicit requests and requirements
- Underlying needs and motivations

### 2. Key Technical Concepts
- Technologies, frameworks, and tools discussed
- Architectural patterns and design decisions
- Important technical constraints and requirements

### 3. Files and Code Sections
- Files examined, created, or modified
- Code snippets with context and purpose
- File relationships and dependencies

### 4. Errors and Fixes
- Problems encountered and solutions found
- User feedback and corrections
- Lessons learned from mistakes

### 5. Problem Solving
- Analytical approaches used
- Decision-making processes
- Alternative solutions considered

### 6. All User Messages
- Complete record of user inputs (excluding tool results)
- Changing intents and new requirements
- Feedback and preferences expressed

### 7. Pending Tasks
- Explicitly assigned work not yet completed
- Dependencies and prerequisites
- Priority and urgency indicators

### 8. Current Work
- Immediate task being worked on
- Recent progress and current state
- Next immediate actions

### 9. Optional Next Step
- Logical continuation of current work
- Directly aligned with user's most recent request
- With explicit quotes showing continuity

## Compression Strategies

### 1. Semantic Compression
- Identify and preserve core meaning
- Remove redundant information
- Consolidate similar concepts
- Maintain technical accuracy

### 2. Hierarchical Compression
- Keep high-level goals and decisions
- Summarize implementation details
- Preserve critical specifics
- Archive less important details

### 3. Temporal Compression
- Recent information gets more detail
- Older information gets more summarization
- Critical historical context preserved
- Transient details archived

### 4. Relevance-Based Compression
- User-focused information prioritized
- Technical details relevant to current task preserved
- Tangential information summarized or removed
- Personal preferences and patterns retained

## Usage Examples

### Basic Compression
```
/compress conversation
/compress memory
/compress session --keep-technical
```

### Targeted Compression
```
/compress last-30-messages
/compress topic:database --preserve-schema
/compress before:new-task --summary-only
```

### Custom Compression
```
/compress --segments 1,3,6,9  # Only key segments
/compress --ratio 0.3  # Compress to 30% of original
/compress --preserve-code --summarize-text
```

## Integration Points

### Session Management
- Automatic compression at context limits
- Smart session continuation after compression
- Seamless context restoration from summaries

### Memory System
- Compress daily memory files
- Create executive summaries for MEMORY.md
- Optimize self-improving memory storage

### Task System
- Compress task context between steps
- Create task summaries for review
- Maintain task continuity across sessions

### Skill Integration
- Memory review skill can trigger compression
- Verification gate can use compressed context
- Kairos lite can schedule regular compression

## Compression Workflow

### Phase 1: Analysis
1. Scan conversation or memory content
2. Identify information types and importance
3. Map to 9-segment structure
4. Calculate compression priorities

### Phase 2: Processing
1. Extract and preserve critical information
2. Summarize less critical details
3. Remove redundancy and noise
4. Maintain logical flow and continuity

### Phase 3: Structuring
1. Organize into 9-segment format
2. Ensure technical accuracy
3. Preserve user intent and preferences
4. Maintain actionable next steps

### Phase 4: Validation
1. Verify no critical information lost
2. Check technical accuracy
3. Ensure readability and usability
4. Confirm compression goals met

## Advanced Features

### Adaptive Compression
- Learn from user feedback on compression quality
- Adapt to different conversation types
- Personalize compression preferences
- Improve over time based on usage patterns

### Multi-Level Compression
- **Light**: Quick summary, preserves recent context
- **Medium**: Balanced compression for most use cases
- **Heavy**: Maximum compression for archiving
- **Custom**: User-defined compression profiles

### Context Restoration
- Expand compressed summaries back to usable context
- Retrieve details from archives when needed
- Maintain bidirectional compression/expansion

### Compression Analytics
- Track compression effectiveness
- Measure information retention
- Analyze compression patterns
- Optimize algorithms based on data

## Technical Implementation

### Compression Algorithms

#### 1. Rule-Based Compression
- Pre-defined rules for different information types
- Pattern matching for common structures
- Heuristic importance scoring

#### 2. ML-Enhanced Compression
- Learn from successful compressions
- Adapt to user preferences and patterns
- Improve technical accuracy preservation

#### 3. Hybrid Approach
- Rule-based for reliability
- ML-enhanced for optimization
- User feedback for continuous improvement

### Data Structures

#### Conversation Graph
- Nodes: Messages, files, concepts, decisions
- Edges: Relationships, dependencies, timelines
- Weights: Importance, recency, relevance

#### Compression Profile
- User preferences and thresholds
- Domain-specific rules
- Historical effectiveness data

#### Compression Cache
- Previously compressed segments
- Expansion mappings
- Quality metrics

## Safety and Quality

### Quality Assurance
- Always preserve user intent and critical requirements
- Never lose technical accuracy in code or configurations
- Maintain ability to continue work from compressed context
- Provide compression quality metrics

### User Control
- Preview compression before applying
- Adjust compression strength and focus
- Exclude specific information from compression
- Manual override for critical sections

### Error Handling
- Detect and recover from compression failures
- Maintain original context as backup
- Provide clear diagnostics for issues
- Support manual context restoration

## Performance Considerations

### Efficiency
- Fast compression for interactive use
- Background compression for large contexts
- Incremental compression for ongoing conversations
- Caching for repeated compression patterns

### Scalability
- Handle conversations of any length
- Efficient memory usage during compression
- Support multiple compression profiles
- Scale with conversation complexity

### Integration Performance
- Minimal impact on normal operation
- Efficient context switching
- Fast compression/expansion cycles
- Low resource overhead

## Use Cases

### Long Development Sessions
```
# After 4 hours of coding
/compress --preserve-code --summarize-discussion
# Continue with clean context but all code preserved
```

### Memory Maintenance
```
# Weekly memory cleanup
/compress memory --archive-old --keep-recent
# Daily files compressed, recent work preserved
```

### Task Handoff
```
# Compress context for another agent or future self
/compress --for-handoff --include-instructions
# Complete but concise context for continuation
```

### Performance Optimization
```
# Reduce context size for faster responses
/compress --optimize-performance --keep-essential
# Smaller context, faster processing, key info preserved
```

## Best Practices

### When to Compress
- Regularly during long sessions (every 50-100 messages)
- Before starting major new tasks
- When context feels cluttered or slow
- Periodically for memory maintenance

### What to Preserve
- User's explicit requests and requirements
- Technical decisions and code changes
- Errors and solutions learned
- Current work state and next steps

### Compression Settings
- Start with medium compression for most cases
- Use light compression for active work
- Use heavy compression for archiving
- Customize based on specific needs

### Quality Verification
- Always review compression summaries
- Test ability to continue work from compressed context
- Provide feedback to improve compression
- Monitor compression effectiveness over time

## Related Skills

- **memory-review** - Uses compression for memory optimization
- **kairos-lite** - Can schedule regular compression tasks
- **verification-gate** - Verifies compression quality
- **dream-memory** - Uses compression for memory consolidation

## Development Roadmap

### Phase 1: Basic Compression
- Rule-based 9-segment compression
- Basic integration with OpenClaw context
- Manual compression triggers

### Phase 2: Advanced Features
- Adaptive compression algorithms
- Multi-level compression profiles
- Context restoration capabilities

### Phase 3: Intelligent Compression
- ML-enhanced compression optimization
- Predictive compression scheduling
- Seamless integration with all OpenClaw systems

## Inspiration

This skill is inspired by Claude Code's proven context compression system but adapted for OpenClaw's diverse use cases beyond just coding conversations, including system administration, personal assistance, and multi-platform interactions.