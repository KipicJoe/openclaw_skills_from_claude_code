---
name: Kairos Lite
slug: kairos-lite
version: 1.0.0
description: "Lightweight scheduled task system for OpenClaw. Create recurring tasks with natural language intervals (e.g., 'every 5 minutes', 'daily at 9 AM')."
metadata:
  openclaw:
    requires:
      bins: []
    os: ["linux", "darwin", "win32"]
    configPaths: []
---

# Kairos Lite - Lightweight Scheduled Tasks for OpenClaw

Create and manage recurring tasks with simple natural language commands.

## When to Use

- When you need to check something periodically (status, updates, etc.)
- For regular maintenance tasks (backups, cleanup, reports)
- To monitor systems or processes on a schedule
- For recurring notifications or reminders

## Features

### Natural Language Scheduling
```
/loop 5m check the weather
/loop 1h backup database
/loop daily at 9 AM send daily report
/loop every 30 minutes monitor server
```

### Interval Support
- **Seconds**: `30s`, `90s` (rounded up to minutes)
- **Minutes**: `5m`, `30m`, `45m`
- **Hours**: `1h`, `6h`, `12h`
- **Days**: `1d`, `7d`, `30d`
- **Time of day**: `at 9 AM`, `at 14:30`

### Smart Parsing
1. **Leading interval**: `5m check status` → every 5 minutes
2. **Trailing "every"**: `check status every 30m` → every 30 minutes
3. **Time of day**: `daily at 9 AM report` → daily at 9:00 AM
4. **Default**: `check status` → every 10 minutes (default)

## How It Works

### 1. Input Parsing
The skill parses natural language to extract:
- Task description/prompt
- Interval or schedule
- Optional time specifications

### 2. Cron Conversion
Converts intervals to cron expressions:
- `5m` → `*/5 * * * *` (every 5 minutes)
- `1h` → `0 * * * *` (hourly at :00)
- `daily at 9 AM` → `0 9 * * *` (daily at 9:00 AM)
- `weekly on Monday` → `0 9 * * 1` (Mondays at 9:00 AM)

### 3. Task Creation
Uses OpenClaw's `cron` tool to create scheduled jobs:
- Recurring tasks with automatic expiration
- Immediate first execution
- Job ID tracking for management

### 4. Task Management
- List active scheduled tasks
- Cancel tasks by ID or description
- View task history and logs
- Modify existing schedules

## Usage Examples

### Basic Recurring Tasks
```
/loop 5m check email for urgent messages
/loop 30m monitor website uptime
/loop 2h backup important files
/loop 1d generate daily summary
```

### Time-Specific Tasks
```
/loop daily at 8 AM send morning briefing
/loop weekdays at 9 AM start work session
/loop weekends at 10 AM leisure check-in
/loop at 17:30 end of day wrap-up
```

### Complex Schedules
```
/loop every Monday at 9 AM weekly planning
/loop 1st of month at 0:00 monthly reset
/loop every 15 minutes during work hours
/loop hourly except 2 AM to 5 AM
```

### Task Management
```
/loop list                    # List all scheduled tasks
/loop cancel check-email      # Cancel specific task
/loop status                  # Show task status
/loop logs 5m-check           # View task logs
```

## Integration with OpenClaw

### Heartbeat Integration
Kairos Lite tasks can trigger heartbeat checks:
- Periodic system monitoring
- Regular memory maintenance
- Scheduled skill executions

### Skill Integration
Schedule other skills to run automatically:
```
/loop 1h /memory-review --recent-days 1
/loop daily at 23:00 /system-cleanup
/loop 30m /health-check --quick
```

### Notification Integration
Tasks can send notifications to various channels:
- WebChat messages
- Discord/Telegram notifications
- Email reports
- System alerts

## Advanced Features

### Conditional Execution
```
/loop 5m check server --only-if "is_work_hours"
/loop 1h backup --if-changed "data/*.db"
/loop daily report --skip-weekends
```

### Chained Tasks
```
/loop 30m "check status && if [ $? -ne 0 ]; then alert admin; fi"
/loop 1h "backup && compress && upload"
```

### Task Templates
Pre-defined task templates for common needs:
```
/loop template:health-check
/loop template:daily-backup --time "2 AM"
/loop template:memory-cleanup --interval "weekly"
```

## Safety Features

### Rate Limiting
- Maximum tasks per user
- Minimum interval enforcement
- Resource usage monitoring

### Permission Controls
- Task creation permissions
- System resource access limits
- Notification channel restrictions

### Error Handling
- Failed task retry logic
- Automatic task disablement on repeated failures
- Error notifications with diagnostics

## Comparison with Native Cron

### Kairos Lite Advantages
- Natural language interface
- Immediate feedback and confirmation
- Integrated with OpenClaw ecosystem
- Task management utilities
- Error handling and notifications

### When to Use Native Cron
- Complex cron expressions not supported by Kairos
- System-level daemons and services
- Tasks requiring precise minute-level control
- Existing cron job migration

## Implementation Notes

### Core Components
1. **Parser** - Natural language to structured schedule
2. **Scheduler** - Cron job creation and management
3. **Executor** - Task execution and monitoring
4. **Notifier** - Status updates and alerts

### Data Storage
- Task definitions in `~/.openclaw/tasks/kairos/`
- Execution logs with timestamps
- Performance metrics and history
- User preferences and templates

### Performance Considerations
- Lightweight parsing with minimal overhead
- Efficient cron job management
- Scalable task execution monitoring
- Minimal impact on system resources

## Getting Started

### Quick Start
```
# Create your first scheduled task
/loop 5m check for updates

# View active tasks
/loop list

# Cancel a task
/loop cancel check-for-updates
```

### Best Practices
1. Start with simple intervals before complex schedules
2. Use descriptive task names for easy management
3. Monitor task performance and adjust as needed
4. Set up notifications for important tasks
5. Regularly review and clean up old tasks

### Common Use Cases
- **System monitoring**: `/loop 1m check system load`
- **Regular backups**: `/loop 6h backup database`
- **Periodic reports**: `/loop daily at 9 AM send report`
- **Maintenance tasks**: `/loop weekly at 2 AM cleanup`
- **Personal reminders**: `/loop 30m take a break`

## Related Skills

- **memory-review** - Schedule regular memory maintenance
- **health-check** - Periodic system health monitoring
- **backup-manager** - Automated backup scheduling
- **notification-center** - Scheduled alerts and reports

## Development Roadmap

### Phase 1 (Current)
- Basic interval parsing and scheduling
- Simple task management
- Integration with OpenClaw cron tool

### Phase 2 (Planned)
- Time-of-day scheduling
- Conditional execution
- Task templates and presets

### Phase 3 (Future)
- Complex schedule expressions
- Task dependencies and workflows
- Advanced monitoring and analytics
- GUI interface for task management

## Inspiration

This skill is inspired by Claude Code's `/loop` skill but adapted for OpenClaw's architecture and user interaction patterns.