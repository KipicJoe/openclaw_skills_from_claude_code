# Memory Review Skill Implementation Guide

This document outlines how to implement the full Memory Review skill for OpenClaw.

## Architecture Overview

The Memory Review skill should be implemented as a proper OpenClaw skill with:

1. **Skill registration** - Register with OpenClaw's skill system
2. **Tool integration** - Use OpenClaw tools for file operations
3. **User interaction** - Present proposals and get approvals
4. **State management** - Track review sessions and changes

## Core Components

### 1. Memory Scanner
```typescript
interface MemoryScanner {
  scanMemoryLayers(options: ScanOptions): Promise<MemoryScanResult>;
  identifyDuplicates(entries: MemoryEntry[]): DuplicateGroup[];
  detectOutdatedEntries(entries: MemoryEntry[]): OutdatedEntry[];
  findConflicts(entries: MemoryEntry[]): Conflict[];
}
```

### 2. Entry Classifier
```typescript
interface EntryClassifier {
  classifyEntry(entry: MemoryEntry, context: ClassificationContext): ClassificationResult;
  suggestDestination(entry: MemoryEntry): MemoryLayer;
  calculateConfidence(classification: ClassificationResult): number;
}
```

### 3. Proposal Generator
```typescript
interface ProposalGenerator {
  generateProposals(analysis: MemoryAnalysis): MemoryProposal[];
  groupProposals(proposals: MemoryProposal[]): GroupedProposals;
  formatProposal(proposal: MemoryProposal): string;
}
```

### 4. Change Executor
```typescript
interface ChangeExecutor {
  executeProposal(proposal: MemoryProposal, approval: UserApproval): Promise<ExecutionResult>;
  createBackup(beforeState: MemoryState): Promise<BackupInfo>;
  rollbackChanges(backup: BackupInfo): Promise<void>;
}
```

## Data Models

### Memory Entry
```typescript
interface MemoryEntry {
  id: string;
  content: string;
  sourceLayer: MemoryLayer;
  sourceFile: string;
  lineNumber: number;
  timestamp: Date;
  metadata: Record<string, any>;
}
```

### Memory Layer
```typescript
enum MemoryLayer {
  LONG_TERM = "MEMORY.md",
  DAILY = "memory/YYYY-MM-DD.md",
  SELF_IMPROVING = "~/self-improving/",
  AGENTS = "AGENTS.md",
  USER = "USER.md",
  SOUL = "SOUL.md",
  TOOLS = "TOOLS.md"
}
```

### Memory Proposal
```typescript
interface MemoryProposal {
  id: string;
  type: ProposalType;
  entry: MemoryEntry;
  suggestedAction: SuggestedAction;
  rationale: string;
  confidence: number;
  requiresApproval: boolean;
}

enum ProposalType {
  PROMOTION = "promotion",
  CLEANUP = "cleanup",
  UPDATE = "update",
  MERGE = "merge",
  ARCHIVE = "archive"
}

enum SuggestedAction {
  MOVE_TO_LAYER = "move_to_layer",
  DELETE = "delete",
  UPDATE_CONTENT = "update_content",
  MERGE_WITH = "merge_with",
  ARCHIVE_FILE = "archive_file"
}
```

## Implementation Steps

### Phase 1: Basic Scanner (Current Implementation)
- [x] Create skill directory structure
- [x] Write SKILL.md documentation
- [x] Create basic shell script for demonstration
- [x] Document implementation plan

### Phase 2: OpenClaw Tool Integration
- [ ] Register skill with OpenClaw
- [ ] Create skill activation trigger (e.g., `/memory-review`)
- [ ] Integrate with `read`, `write`, `edit` tools
- [ ] Add user interaction via chat interface

### Phase 3: Advanced Analysis
- [ ] Implement semantic analysis of memory entries
- [ ] Add duplicate detection with fuzzy matching
- [ ] Implement conflict resolution logic
- [ ] Add timestamp-based outdated detection

### Phase 4: User Interface
- [ ] Create interactive proposal presentation
- [ ] Add approval workflow
- [ ] Implement batch operations
- [ ] Add progress reporting

### Phase 5: Integration Features
- [ ] Add heartbeat integration for periodic reviews
- [ ] Create cron job setup helper
- [ ] Add backup and rollback functionality
- [ ] Implement export/import capabilities

## OpenClaw Tool Usage Examples

### Reading Memory Files
```javascript
// Use OpenClaw's read tool
const memoryContent = await openclaw.tools.read({
  path: "/root/.openclaw/workspace/MEMORY.md"
});

// Scan daily memory files
const dailyFiles = await openclaw.tools.exec({
  command: "find /root/.openclaw/workspace/memory -name '*.md' -type f"
});
```

### Presenting Proposals to User
```javascript
// Format proposal for user approval
const proposalMessage = `
📋 Memory Review Proposal #${proposal.id}

**Action**: ${proposal.suggestedAction}
**From**: ${proposal.entry.sourceLayer} (line ${proposal.entry.lineNumber})
**To**: ${proposal.suggestedDestination || 'DELETE'}
**Rationale**: ${proposal.rationale}

**Content**:
\`\`\`
${proposal.entry.content}
\`\`\`

Approve this change? (yes/no/skip)
`;

// Send to user and await response
const userResponse = await openclaw.tools.askUser(proposalMessage);
```

### Executing Approved Changes
```javascript
// Use OpenClaw's edit tool for precise modifications
if (proposal.suggestedAction === SuggestedAction.MOVE_TO_LAYER) {
  await openclaw.tools.edit({
    path: proposal.entry.sourceFile,
    edits: [{
      oldText: proposal.entry.content,
      newText: "" // Remove from source
    }]
  });
  
  await openclaw.tools.edit({
    path: getDestinationPath(proposal.suggestedDestination),
    edits: [{
      oldText: "", // Append to end
      newText: `\n${proposal.entry.content}`
    }]
  });
}
```

## Testing Strategy

### Unit Tests
- Memory entry parsing and classification
- Duplicate detection algorithms
- Conflict resolution logic

### Integration Tests
- File system operations
- Tool integration
- User interaction flows

### End-to-End Tests
- Complete memory review workflow
- Error handling and recovery
- Performance with large memory sets

## Performance Considerations

1. **Incremental Scanning**: Only scan changed files since last review
2. **Caching**: Cache analysis results for repeated reviews
3. **Batch Operations**: Group similar operations together
4. **Progress Reporting**: Provide feedback during long scans

## Security Considerations

1. **Permission Boundaries**: Respect MEMORY.md security rules
2. **Backup Creation**: Always create backups before making changes
3. **User Approval**: Never make changes without explicit approval
4. **Audit Logging**: Log all changes made by the skill

## Future Enhancements

1. **Machine Learning**: Use ML for better entry classification
2. **Pattern Recognition**: Identify recurring patterns across sessions
3. **Automated Summarization**: Generate summaries of memory content
4. **Cross-Workspace Analysis**: Compare memory across different workspaces
5. **Export Formats**: Export memory in various formats (JSON, CSV, etc.)

## Integration with Other Skills

### With Self-Improving Skill
- Use self-improving memory as input for pattern recognition
- Update self-improving memory based on review findings
- Share classification rules between skills

### With Context-Compressor Skill
- Use compression for large memory files
- Integrate compression into cleanup proposals
- Share compression heuristics

### With Style-Extractor Skill
- Extract user preferences during memory review
- Update USER.md based on identified patterns
- Share preference detection logic

## Getting Started

To implement the full skill:

1. Study OpenClaw's skill development documentation
2. Review existing skills for implementation patterns
3. Start with the basic scanner and gradually add features
4. Test with sample memory data before live deployment
5. Get user feedback and iterate on the design

## References

- OpenClaw Skill Development Guide
- Claude Code `remember` skill source code
- Memory management best practices
- User experience design for approval workflows