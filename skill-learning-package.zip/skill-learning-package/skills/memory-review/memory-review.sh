#!/bin/bash
# Memory Review Skill for OpenClaw
# Simple shell implementation for demonstration

set -e

WORKSPACE="/root/.openclaw/workspace"
SELF_IMPROVING_DIR="/root/self-improving"

# Default options
RECENT_DAYS=7
DRY_RUN=false
AUTO_APPROVE_MINOR=false
FULL_SCAN=false

# Parse arguments
while [[ $# -gt 0 ]]; do
  case $1 in
    --recent-days)
      RECENT_DAYS="$2"
      shift 2
      ;;
    --dry-run)
      DRY_RUN=true
      shift
      ;;
    --auto-approve-minor)
      AUTO_APPROVE_MINOR=true
      shift
      ;;
    --full-scan)
      FULL_SCAN=true
      shift
      ;;
    *)
      echo "Unknown option: $1"
      exit 1
      ;;
  esac
done

echo "🔍 OpenClaw Memory Review"
echo "========================="
echo "Workspace: $WORKSPACE"
echo "Recent days to review: $RECENT_DAYS"
echo "Dry run: $DRY_RUN"
echo "Auto-approve minor: $AUTO_APPROVE_MINOR"
echo ""

# Function to check if file exists and is readable
check_file() {
  if [[ -f "$1" && -r "$1" ]]; then
    return 0
  else
    return 1
  fi
}

# Function to count lines in file
count_lines() {
  if check_file "$1"; then
    wc -l < "$1" | tr -d ' '
  else
    echo "0"
  fi
}

# Function to get file size
get_size() {
  if check_file "$1"; then
    du -h "$1" | cut -f1
  else
    echo "0B"
  fi
}

# Phase 1: Memory Gathering
echo "📊 Phase 1: Gathering Memory Statistics"
echo "--------------------------------------"

# Check MEMORY.md
if check_file "$WORKSPACE/MEMORY.md"; then
  MEMORY_LINES=$(count_lines "$WORKSPACE/MEMORY.md")
  MEMORY_SIZE=$(get_size "$WORKSPACE/MEMORY.md")
  echo "✓ MEMORY.md: $MEMORY_LINES lines ($MEMORY_SIZE)"
else
  echo "✗ MEMORY.md: Not found or not readable"
fi

# Check daily memory files
DAILY_FILES_COUNT=0
if [[ -d "$WORKSPACE/memory" ]]; then
  if [[ "$FULL_SCAN" == "true" ]]; then
    DAILY_FILES_COUNT=$(find "$WORKSPACE/memory" -name "*.md" -type f | wc -l)
  else
    # Find recent files (last N days)
    RECENT_DATE=$(date -d "$RECENT_DAYS days ago" +%Y-%m-%d)
    DAILY_FILES_COUNT=$(find "$WORKSPACE/memory" -name "*.md" -type f -newermt "$RECENT_DATE" | wc -l)
  fi
  echo "✓ Daily memory files: $DAILY_FILES_COUNT files (last $RECENT_DAYS days)"
else
  echo "✗ memory/ directory: Not found"
fi

# Check self-improving memory
if [[ -d "$SELF_IMPROVING_DIR" ]]; then
  SI_FILES_COUNT=$(find "$SELF_IMPROVING_DIR" -name "*.md" -type f | wc -l)
  echo "✓ Self-improving memory: $SI_FILES_COUNT files in $SELF_IMPROVING_DIR/"
else
  echo "✗ Self-improving directory: Not found at $SELF_IMPROVING_DIR"
fi

# Check configuration files
CONFIG_FILES=("AGENTS.md" "USER.md" "SOUL.md" "TOOLS.md")
for config in "${CONFIG_FILES[@]}"; do
  if check_file "$WORKSPACE/$config"; then
    LINES=$(count_lines "$WORKSPACE/$config")
    SIZE=$(get_size "$WORKSPACE/$config")
    echo "✓ $config: $LINES lines ($SIZE)"
  else
    echo "✗ $config: Not found"
  fi
done

echo ""
echo "📈 Phase 2: Analysis"
echo "-------------------"

# Simple analysis examples
echo "Running basic analysis..."

# Check for very large MEMORY.md (suggest compression)
if [[ $MEMORY_LINES -gt 500 ]]; then
  echo "⚠️  MEMORY.md is large ($MEMORY_LINES lines). Consider compression or archiving old entries."
fi

# Check for old daily files
if [[ -d "$WORKSPACE/memory" ]]; then
  OLD_FILES=$(find "$WORKSPACE/memory" -name "*.md" -type f -mtime +30 | wc -l)
  if [[ $OLD_FILES -gt 0 ]]; then
    echo "⚠️  Found $OLD_FILES daily memory files older than 30 days. Consider archiving."
  fi
fi

# Check self-improving index consistency
if [[ -f "$SELF_IMPROVING_DIR/index.md" ]]; then
  INDEXED_FILES=$(grep -c "\.md:" "$SELF_IMPROVING_DIR/index.md" || echo "0")
  ACTUAL_FILES=$(find "$SELF_IMPROVING_DIR" -name "*.md" -type f | wc -l)
  if [[ $INDEXED_FILES -ne $((ACTUAL_FILES - 1)) ]]; then
    echo "⚠️  Self-improving index may be out of sync (indexed: $INDEXED_FILES, actual: $((ACTUAL_FILES - 1)))"
  fi
fi

echo ""
echo "💡 Phase 3: Recommendations"
echo "--------------------------"

echo "Based on the analysis, here are recommendations:"
echo ""
echo "1. **Regular Maintenance**"
echo "   - Run memory review weekly to keep memory organized"
echo "   - Consider setting up a cron job for automatic reviews"
echo ""
echo "2. **Memory Optimization**"
if [[ $MEMORY_LINES -gt 500 ]]; then
  echo "   - Compress or archive old entries in MEMORY.md"
fi
if [[ $OLD_FILES -gt 0 ]]; then
  echo "   - Archive daily memory files older than 30 days"
fi
echo ""
echo "3. **Skill Integration**"
echo "   - Use the 'context-compressor' skill (when available) for memory compression"
echo "   - Integrate with 'self-improving' skill for execution quality tracking"
echo ""
echo "4. **Next Steps**"
echo "   - Review specific entries that need attention"
echo "   - Consider creating a memory maintenance schedule"
echo "   - Document important patterns in appropriate memory layers"

echo ""
echo "✅ Memory review completed."
echo ""
echo "Note: This is a basic implementation. For full functionality:"
echo "- The skill should be implemented as a proper OpenClaw skill with tool integration"
echo "- Should include detailed entry-by-entry analysis"
echo "- Should support interactive user approval for changes"
echo "- Should integrate with OpenClaw's tool system for file operations"

exit 0