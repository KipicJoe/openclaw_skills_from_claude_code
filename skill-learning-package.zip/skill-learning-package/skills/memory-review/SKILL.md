---
name: Memory Review
slug: memory-review
version: 1.0.0
description: "Review and organize memory layers in OpenClaw workspace. Identifies duplicates, outdated entries, and conflicts across MEMORY.md, daily memory files, self-improving memory, and configuration files."
metadata:
  openclaw:
    requires:
      bins: []
    os: ["linux", "darwin", "win32"]
    configPaths: ["./MEMORY.md", "./memory/", "./AGENTS.md", "./USER.md", "./SOUL.md", "./TOOLS.md"]
---

# Memory Review Skill for OpenClaw

Review, organize, and optimize memory layers in your OpenClaw workspace.

## When to Use

- When memory files become cluttered or disorganized
- Before important projects to ensure clean memory context
- Periodically (e.g., weekly/monthly) for maintenance
- When you notice contradictions or duplicates in memory

## Memory Layers in OpenClaw

OpenClaw uses a tiered memory system:

### 1. Long-Term Memory (`MEMORY.md`)
- Curated memories, important decisions, lessons learned
- Loaded only in main sessions (security boundary)
- Distilled essence, not raw logs

### 2. Daily Memory (`memory/YYYY-MM-DD.md`)
- Raw session logs of what happened each day
- Factual continuity: events, context, decisions
- Created automatically during sessions

### 3. Self-Improving Memory (`~/self-improving/`)
- Execution quality improvement memory
- Preferences, workflows, style patterns
- What improved/worsened outcomes

### 4. Configuration Files
- `AGENTS.md` - Workspace conventions and rules
- `USER.md` - Information about the human
- `SOUL.md` - Agent personality and behavior
- `TOOLS.md` - Environment-specific tool notes

## Skill Workflow

### Phase 1: Memory Gathering
1. Read `MEMORY.md` (if in main session)
2. Scan recent `memory/YYYY-MM-DD.md` files (last 7 days)
3. Read `~/self-improving/` memory files
4. Review configuration files

### Phase 2: Analysis
1. **Identify duplicates** - Same information in multiple layers
2. **Detect outdated entries** - Old information contradicted by newer entries
3. **Find conflicts** - Contradictions between different memory sources
4. **Classify entries** - Determine the appropriate layer for each memory

### Phase 3: Proposal Generation
Present a structured report with:

1. **Promotions** - Entries to move to more appropriate layers
2. **Cleanup** - Duplicates, outdated entries, conflicts to resolve
3. **Ambiguous** - Entries needing user clarification
4. **No action needed** - Entries that should stay where they are

### Phase 4: User Approval & Execution
1. Present proposals for user review
2. Get explicit approval for each change
3. Execute approved changes
4. Confirm completion

## Classification Guidelines

| Destination | What belongs there | Examples |
|---|---|---|
| **MEMORY.md** | Significant events, important decisions, lessons worth remembering long-term | "Decided to use PostgreSQL over MySQL for project X", "Learned that user prefers concise technical explanations", "Important security policy established on 2026-03-15" |
| **Daily memory** | Raw session logs, factual context, one-time events | "Helped debug API issue at 14:30", "User asked about weather in Tokyo", "Ran system update command" |
| **Self-improving** | Execution patterns, user preferences, workflow optimizations | "User prefers bullet lists over tables in Discord", "Always check file permissions before editing", "Use `trash` instead of `rm` for safety" |
| **AGENTS.md** | Workspace conventions, tool usage rules, session guidelines | "Read SOUL.md at session startup", "Use heartbeat for periodic checks", "Ask before external actions" |
| **USER.md** | Personal information about the human | "Name: Alex", "Timezone: UTC+8", "Working on project Alpha" |
| **SOUL.md** | Agent personality traits, communication style | "Be genuinely helpful, not performatively helpful", "Have opinions but respect boundaries" |
| **TOOLS.md** | Environment-specific configurations | "Camera names: living-room, front-door", "SSH alias: home-server → 192.168.1.100" |

## Safety Rules

1. **Never delete without asking** - Always propose, never auto-delete
2. **Preserve history** - Keep original context when moving entries
3. **Respect security boundaries** - Don't load MEMORY.md in shared contexts
4. **Ask about ambiguous entries** - When unsure, seek clarification
5. **Backup before major changes** - Suggest creating backups for large reorganizations

## Integration Points

- **Heartbeat**: Can be triggered periodically via heartbeat
- **Cron**: Scheduled memory review jobs
- **Manual invocation**: User can run `/memory-review` when needed
- **Post-task cleanup**: After large projects, suggest memory review

## Related Skills

- `self-improving` - For execution quality memory
- `context-compressor` - For compressing memory files
- `style-extractor` - For identifying user preferences

## Quick Start

To use this skill manually:
```
/memory-review [options]
```

Options:
- `--recent-days 7` - Number of recent daily files to review (default: 7)
- `--full-scan` - Review all memory files, not just recent
- `--dry-run` - Show proposals without making changes
- `--auto-approve-minor` - Auto-approve minor cleanup suggestions

## Development Notes

This skill is inspired by Claude Code's `remember` skill but adapted for OpenClaw's architecture and memory system.