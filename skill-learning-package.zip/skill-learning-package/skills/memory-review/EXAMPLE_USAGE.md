# Memory Review Skill - Example Usage

This document shows how the Memory Review skill would work in practice.

## Basic Usage

### 1. Manual Invocation
```
User: /memory-review
Agent: Starting memory review...
       Scanning memory layers...
       
       📊 Memory Statistics:
       - MEMORY.md: 42 lines (2.1KB)
       - Daily memory files: 7 files (last 7 days)
       - Self-improving memory: 4 files
       - Configuration files: All present
       
       🔍 Analysis Results:
       - Found 3 potential duplicates
       - Found 2 outdated entries
       - Found 1 conflict between layers
       
       💡 Recommendations:
       1. Move 2 entries from daily memory to MEMORY.md
       2. Delete 1 duplicate entry from self-improving memory
       3. Update 1 outdated entry in AGENTS.md
       
       Shall I proceed with these changes? (yes/no/details)
```

### 2. With Options
```
User: /memory-review --recent-days 30 --dry-run
Agent: Running memory review in dry-run mode...
       Scanning last 30 days of memory...
       
       📋 Dry Run Report:
       Would propose 15 changes:
       - 8 promotions to MEMORY.md
       - 4 cleanups in daily memory
       - 3 updates to configuration files
       
       No changes will be made in dry-run mode.
```

### 3. Interactive Approval
```
Agent: 📋 Proposal #1: Promote entry to MEMORY.md
       From: memory/2026-03-28.md (line 15)
       Content: "User prefers concise explanations with code examples"
       Rationale: This is a user preference worth remembering long-term
       
       Approve? (yes/no/skip)
User: yes

Agent: ✅ Approved. Moving entry...
       
       📋 Proposal #2: Delete duplicate entry
       From: ~/self-improving/memory.md (line 8)
       Duplicate of: MEMORY.md (line 23)
       Content: "Always use `trash` instead of `rm`"
       
       Approve? (yes/no/skip)
User: no

Agent: ⏭️ Skipped. Entry preserved.
```

## Real-World Scenarios

### Scenario 1: Weekly Maintenance
```
# Set up weekly memory review via cron
User: Set up a weekly memory review every Monday at 9 AM

Agent: Creating cron job for memory review...
       ✅ Scheduled: /memory-review --recent-days 7 --auto-approve-minor
       Will run every Monday at 09:00 UTC
       
       Weekly report will be sent to this channel.
```

### Scenario 2: Pre-Project Cleanup
```
User: I'm starting a new project. Clean up my memory first.

Agent: Running comprehensive memory review...
       Scanning all memory layers...
       
       🧹 Pre-Project Memory Cleanup Complete:
       - Archived 12 old daily memory files (>90 days)
       - Compressed MEMORY.md from 512 to 287 lines
       - Organized self-improving memory by project
       - Updated USER.md with current project context
       
       Your memory is now optimized for the new project.
```

### Scenario 3: Conflict Resolution
```
Agent: ⚠️ Conflict Detected:
       MEMORY.md says: "User prefers dark theme"
       TOOLS.md says: "User prefers light theme"
       
       Both were updated recently. Which is correct?
       
       Options:
       1. Update MEMORY.md to match TOOLS.md
       2. Update TOOLS.md to match MEMORY.md
       3. Keep both with timestamp notes
       4. Ask user for clarification
       
User: 4

Agent: User, you have conflicting preferences recorded:
       - MEMORY.md says you prefer dark theme
       - TOOLS.md says you prefer light theme
       
       Which is your current preference?
User: I prefer dark theme for coding, light for documentation.

Agent: ✅ Updated both files with clarification:
       MEMORY.md: "User prefers dark theme for coding work"
       TOOLS.md: "User prefers light theme for documentation review"
```

### Scenario 4: Pattern Discovery
```
Agent: 🔍 Pattern Discovery:
       Found recurring pattern in daily memory:
       - 5 instances of "User asks for weather updates"
       - 3 instances of "User prefers Fahrenheit over Celsius"
       - 7 instances of "User works late on Thursdays"
       
       Suggestions:
       1. Add to USER.md: "Interested in weather updates, prefers °F"
       2. Add to self-improving: "Check weather proactively on Thursdays"
       3. Consider creating a 'weather' skill for quick access
       
       Apply these pattern-based updates?
```

## Integration Examples

### With Heartbeat System
```yaml
# HEARTBEAT.md addition
## Memory Maintenance
- Run /memory-review --recent-days 3 every 3 days
- Flag if MEMORY.md exceeds 500 lines
- Suggest archiving for files >30 days old
```

### With Self-Improving Skill
```
# After a memory review, update self-improving memory
Agent: Memory review completed. Updating self-improving patterns...
       
       Added to ~/self-improving/memory.md:
       - "User approves 80% of MEMORY.md promotion suggestions"
       - "Best time for memory review: Monday mornings"
       - "Optimal MEMORY.md size: 200-300 lines"
```

### With Notification System
```
# After automated review
Agent: 📬 Weekly Memory Review Report
       Date: 2026-04-02
       
       📈 Statistics:
       - Total entries reviewed: 1,247
       - Changes proposed: 23
       - Changes approved: 18 (78%)
       
       🎯 Top Actions:
       1. Promoted 12 entries to long-term memory
       2. Cleaned 4 duplicate workflow patterns
       3. Updated 2 outdated tool configurations
       
       📊 Health Metrics:
       - MEMORY.md size: 287 lines (healthy)
       - Daily memory growth: 42 files/month
       - Self-improving accuracy: 92%
       
       ✅ Memory system is healthy and well-maintained.
```

## Advanced Features

### 1. Memory Export
```
User: Export my memory for backup

Agent: Creating memory export...
       📦 Memory Export Package:
       - MEMORY.md (current state)
       - Last 30 days of daily memory
       - Complete self-improving memory
       - All configuration files
       - Change history log
       
       Export saved to: /backups/memory-2026-04-02.zip
```

### 2. Cross-Project Analysis
```
User: Compare memory between Project A and Project B

Agent: Analyzing memory across projects...
       
       🔄 Cross-Project Insights:
       - Common patterns: Both use PostgreSQL, prefer REST APIs
       - Differences: Project A uses Docker, Project B uses Kubernetes
       - User preferences: Consistent across projects
       
       Recommendations:
       1. Create shared memory layer for common patterns
       2. Keep project-specific configurations separate
       3. Update USER.md with cross-project insights
```

### 3. Memory Visualization
```
User: Show me a visualization of my memory

Agent: Generating memory visualization...
       
       📊 Memory Landscape:
       ```
       Long-term (MEMORY.md): ██████████ 42 entries
       Daily (last 30 days):  ███████████████ 127 entries
       Self-improving:        ███████ 28 patterns
       Configurations:        ███ 15 settings
       
       Growth Trend: ↗️ 12% this month
       Health Score: 88/100
       ```
       
       Interactive chart available at: /memory-dashboard.html
```

## Error Handling Examples

### 1. Permission Issues
```
Agent: ⚠️ Cannot access MEMORY.md in this context
       (Security boundary: MEMORY.md only loaded in main sessions)
       
       Continuing with available memory layers...
       Reviewing: Daily memory, self-improving, configurations
```

### 2. Corrupted Files
```
Agent: ⚠️ Corrupted file detected: memory/2026-03-15.md
       Line 42 has malformed Markdown
       
       Options:
       1. Attempt repair (may lose some data)
       2. Skip this file
       3. Move to quarantine for manual review
       
User: 1

Agent: 🔧 Repairing file...
       Fixed 3 formatting issues
       Preserved 28 of 30 original entries
       ✅ File repaired successfully
```

### 3. Insufficient Memory
```
Agent: ⚠️ Insufficient memory data for meaningful review
       Only found 2 daily memory files (minimum 5 recommended)
       
       Suggestions:
       1. Continue with limited review
       2. Wait until more memory accumulates
       3. Import memory from backup
       
User: 1

Agent: ⚠️ Limited review mode activated
       Results may be less accurate with limited data
       Consider running again in 3 days
```

## Best Practices

### 1. Regular Schedule
- Weekly: Quick review of recent memory
- Monthly: Comprehensive review of all layers
- Quarterly: Deep cleanup and optimization

### 2. Before/After Major Events
- Before starting new projects
- After completing major tasks
- When changing work environments

### 3. Monitoring Metrics
- MEMORY.md size (keep under 500 lines)
- Daily memory growth rate
- Review accuracy (approval rate)
- System performance impact

### 4. User Preferences
- Set default approval thresholds
- Configure notification preferences
- Customize classification rules
- Define archiving policies

## Conclusion

The Memory Review skill transforms memory management from a manual chore into an intelligent, automated process. By learning from Claude Code's approach and adapting it to OpenClaw's architecture, we create a powerful tool for maintaining clean, organized, and useful memory systems.

Start with basic reviews and gradually enable more advanced features as users become comfortable with the system.