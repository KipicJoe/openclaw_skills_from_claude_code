---
name: Verification Gate
slug: verification-gate
version: 1.0.0
description: "Post-task verification system for OpenClaw. After completing a task, run verification checks to ensure everything works as expected."
metadata:
  openclaw:
    requires:
      bins: []
    os: ["linux", "darwin", "win32"]
    configPaths: []
---

# Verification Gate - Post-Task Verification for OpenClaw

Ensure task completion quality by running verification checks after important tasks.

## When to Use

- After making code changes or file edits
- After system configuration modifications
- After running complex commands or scripts
- After completing multi-step workflows
- When task success is critical

## Core Concept

The "Verification Gate" pattern:
1. **Complete** the primary task
2. **Pause** before marking as done
3. **Verify** that everything works as expected
4. **Proceed** only after verification passes

This prevents "it looked right but actually broke something" scenarios.

## Verification Types

### 1. File Verification
- Check file syntax and validity
- Verify permissions and ownership
- Confirm expected content exists
- Validate file encoding and format

### 2. Code Verification
- Syntax checking for various languages
- Compilation or build verification
- Test suite execution
- Linting and style checks

### 3. System Verification
- Service status checks
- Process monitoring
- Resource availability
- Network connectivity

### 4. Functional Verification
- Run the application to test functionality
- Check API endpoints
- Verify user interface elements
- Test integration points

### 5. Safety Verification
- Backup integrity checks
- Rollback capability verification
- Permission and security validation
- Compliance with policies

## Usage Patterns

### Automatic Verification
```
# After editing a configuration file
/edit /etc/nginx/nginx.conf
/verify config syntax

# After deploying code
/deploy app-v2.1
/verify service health

# After database migration
/migrate-db schema-v3
/verify data integrity
```

### Manual Verification Request
```
User: I just updated the API server. Can you verify it's working?

Agent: Running verification checks...
       ✅ API endpoint responding (200 OK)
       ✅ Database connection healthy
       ✅ Cache service available
       ✅ Response time < 100ms
       
       All verification checks passed. Update successful.
```

### Integrated Verification
```
# As part of a workflow
/task: Update website
  Steps:
  1. Backup current site
  2. Deploy new version
  3. /verify site functionality
  4. Notify team
```

## Verification Methods

### 1. Command Execution
```
/verify "systemctl status nginx"
/verify "curl -f http://localhost:8080/health"
/verify "python -m py_compile app.py"
```

### 2. File Checks
```
/verify file:/etc/nginx/nginx.conf --syntax
/verify file:app.js --lint
/verify file:database.db --integrity
```

### 3. Custom Verification Scripts
```
/verify script:./verify-deployment.sh
/verify script:custom --args "prod environment"
```

### 4. Multi-Step Verification
```
/verify suite:deployment
  - check service status
  - verify endpoints
  - test functionality
  - monitor performance
```

## Integration with Tasks

### Post-Task Hooks
Automatically run verification after specific tasks:
- File edits → syntax verification
- Service restarts → status verification
- Deployments → functionality verification
- Configuration changes → compliance verification

### Task Completion Gates
Prevent task completion until verification passes:
```
Task: Update firewall rules
Status: Completed configuration
Gate: Verification required
Action: /verify firewall rules
Result: ✅ Verified → Task complete
       ❌ Failed → Rollback and notify
```

### Verification Profiles
Pre-defined verification sets for common tasks:
```
/verify profile:web-deployment
/verify profile:database-migration  
/verify profile:security-update
/verify profile:system-upgrade
```

## Verification Workflow

### 1. Define Verification Criteria
What needs to be true for the task to be considered successful?

### 2. Execute Verification Checks
Run the actual verification commands or scripts.

### 3. Analyze Results
Interpret verification output and determine pass/fail status.

### 4. Take Action
- **All passed**: Mark task complete, proceed normally
- **Some failed**: Provide diagnostics, suggest fixes
- **Critical failures**: Trigger rollback, alert urgently

### 5. Document Results
Record verification outcomes for audit and learning.

## Safety Features

### Fail-Safe Design
- Verification failures prevent incorrect "success" marking
- Clear failure messages with actionable diagnostics
- Automatic rollback options for critical failures

### Escalation Paths
- Notification of verification failures
- Escalation to human review when automated checks uncertain
- Historical tracking of verification outcomes

### Learning System
- Track which verification checks are most valuable
- Learn from false positives/negatives
- Improve verification accuracy over time

## Examples

### Example 1: Web Server Update
```
Task: Update Nginx configuration
Verification:
1. /verify "nginx -t"  # Syntax check
2. /verify "systemctl reload nginx"  # Reload without downtime
3. /verify "curl -I http://localhost"  # Server responding
4. /verify "grep 'error' /var/log/nginx/error.log | tail -5"  # No new errors
```

### Example 2: Python Package Installation
```
Task: Install new Python package
Verification:
1. /verify "python -c 'import new_package'"  # Import works
2. /verify "pip show new_package"  # Correct version installed
3. /verify script:test_new_package.py  # Custom functionality test
```

### Example 3: System Configuration
```
Task: Update system limits
Verification:
1. /verify file:/etc/security/limits.conf --syntax
2. /verify "ulimit -n"  # Current limit check
3. /verify "su - testuser -c 'ulimit -n'"  # Applies to users
4. /verify "service sshd restart"  # Services restart cleanly
```

## Advanced Features

### Verification Chains
```
/verify chain:deployment
  → check syntax
  → run tests
  → deploy staging
  → verify staging
  → deploy production
  → verify production
  → notify completion
```

### Conditional Verification
```
/verify "service status" --if-changed "/etc/service.conf"
/verify "app functionality" --only-in "production"
/verify "backup integrity" --after "database-update"
```

### Verification Templates
```
/verify template:web-app
  - syntax check
  - unit tests
  - integration tests
  - deployment check
  - smoke tests
```

### Historical Verification
```
/verify history:last-5-deployments
/verify compare:staging-vs-production
/verify trend:error-rate --over "7 days"
```

## Integration with OpenClaw

### Skill Integration
Other skills can trigger verification:
- `deploy` skill → post-deployment verification
- `edit` skill → syntax verification
- `config` skill → configuration validation

### Notification Integration
Verification results can notify:
- Success/failure notifications
- Detailed verification reports
- Historical trend alerts

### Learning Integration
Verification outcomes feed into:
- Self-improving skill patterns
- Task success prediction
- Risk assessment models

## Implementation Approach

### Phase 1: Basic Verification
- Simple command execution verification
- File syntax checking
- Basic integration with existing tools

### Phase 2: Advanced Verification
- Verification profiles and templates
- Multi-step verification chains
- Historical tracking and analytics

### Phase 3: Intelligent Verification
- Machine learning for verification optimization
- Predictive failure detection
- Adaptive verification strategies

## Best Practices

### 1. Start Simple
Begin with basic syntax and status checks before complex verification.

### 2. Be Specific
Clearly define what "success" means for each verification.

### 3. Document Assumptions
Record what each verification check assumes about the system state.

### 4. Review Regularly
Periodically review and update verification criteria as systems evolve.

### 5. Learn from Failures
Use verification failures to improve both tasks and verification checks.

## Related Skills

- **kairos-lite** - Schedule periodic verification tasks
- **memory-review** - Verify memory system integrity
- **health-check** - System health verification
- **backup-verifier** - Backup integrity verification

## Inspiration

This skill is inspired by Claude Code's verification system but adapted for OpenClaw's task-oriented architecture and broader use cases beyond just code verification.