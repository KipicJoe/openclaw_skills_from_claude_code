---
name: Style Extractor
slug: style-extractor
version: 1.0.0
description: "Extract user preferences, collaboration styles, and interaction patterns from conversations. Learn how users prefer to work and adapt accordingly."
metadata:
  openclaw:
    requires:
      bins: []
    os: ["linux", "darwin", "win32"]
    configPaths: ["./USER.md", "./SOUL.md", "./TOOLS.md", "./memory/"]
---

# Style Extractor - Learn User Preferences and Collaboration Patterns

Automatically extract and learn from user interaction patterns to provide more personalized and effective assistance.

## When to Use

- After significant interactions to capture learning
- When noticing recurring patterns or preferences
- Periodically to update user profile
- Before important tasks to ensure alignment with user style
- When user provides explicit feedback or corrections

## What Gets Extracted

### 1. Communication Preferences
- **Response style**: Concise vs. detailed, technical vs. layman
- **Format preferences**: Bullet points, tables, code blocks, paragraphs
- **Tone and formality**: Casual, professional, technical, friendly
- **Feedback style**: Direct, suggestive, detailed, brief

### 2. Technical Preferences
- **Tool preferences**: Favorite commands, tools, workflows
- **Code style**: Naming conventions, formatting, patterns
- **System preferences**: Operating systems, editors, environments
- **Security practices**: Permission levels, confirmation habits

### 3. Workflow Patterns
- **Task approach**: Sequential vs. parallel, detailed vs. high-level
- **Decision making**: Quick decisions vs. thorough analysis
- **Error handling**: Immediate fix vs. root cause analysis
- **Learning style**: Examples vs. explanations, visual vs. textual

### 4. Personal Preferences
- **Time patterns**: Active hours, response expectations
- **Notification preferences**: When and how to notify
- **Priority signals**: What indicates urgency vs. routine
- **Boundary preferences**: When to ask vs. when to act

### 5. Domain Expertise
- **Technical domains**: Areas of expertise and interest
- **Learning interests**: Topics user wants to explore
- **Skill levels**: Proficiency in different areas
- **Knowledge gaps**: Areas where user seeks more help

## Extraction Methods

### 1. Explicit Feedback Analysis
- Direct corrections and instructions
- "I prefer..." statements
- "Don't do that, do this instead" patterns
- Positive reinforcement of specific approaches

### 2. Pattern Recognition
- Recurring request patterns
- Consistent workflow choices
- Repeated tool or command usage
- Regular timing or scheduling patterns

### 3. Implicit Preference Detection
- Which suggestions get implemented vs. ignored
- Response time and engagement patterns
- Follow-up question types and depth
- Satisfaction indicators in responses

### 4. Comparative Analysis
- Compare current session patterns with historical data
- Identify changes in preferences over time
- Detect evolving expertise and interests
- Track learning and skill development

## Usage Patterns

### Automatic Extraction
```
# Runs automatically after significant interactions
[After completing complex task]
Style Extractor: Detected new preferences:
- User prefers code examples with explanations
- Favors bullet points over paragraphs for instructions
- Likes proactive suggestions for next steps
Updated USER.md with these preferences.
```

### Manual Extraction Request
```
User: Can you analyze my preferences from our recent work?

Style Extractor: Analyzing last 7 days of interactions...
Found patterns:
1. Communication: Prefers concise technical explanations
2. Workflow: Likes step-by-step plans before execution
3. Tools: Frequently uses git, docker, python
4. Timing: Most active 9 AM - 5 PM UTC
Updated profile with 12 new preference entries.
```

### Periodic Review
```
# Scheduled weekly extraction
Style Extractor: Weekly preference review complete:
- Added 3 new workflow preferences
- Updated 2 existing preferences based on recent usage
- Archived 1 outdated preference (no longer relevant)
- Confidence scores updated for 15 preferences
Report saved to style-review-2026-04-02.md
```

## Integration Points

### User Profile Updates
- Update `USER.md` with discovered preferences
- Refine `SOUL.md` interaction guidelines
- Enhance `TOOLS.md` with user-specific configurations
- Create personalized skill recommendations

### Self-Improving System
- Feed preferences into self-improving memory
- Improve future interactions based on learned patterns
- Adapt skill recommendations to user style
- Optimize communication and workflow approaches

### Task Optimization
- Tailor task approaches to user preferences
- Adjust communication style for different task types
- Optimize tool recommendations based on past success
- Personalize verification and quality checks

### Skill Personalization
- Customize other skills based on user style
- Adapt memory-review to user's organization preferences
- Tailor kairos-lite scheduling to user's active hours
- Personalize swarm-coordinator communication style

## Extraction Workflow

### Phase 1: Data Collection
1. Gather conversation history and interaction logs
2. Collect task completion patterns and outcomes
3. Analyze tool usage and command history
4. Review feedback and correction patterns

### Phase 2: Pattern Analysis
1. Identify recurring themes and preferences
2. Detect changes and evolution over time
3. Calculate confidence scores for each pattern
4. Categorize patterns by type and importance

### Phase 3: Preference Synthesis
1. Combine related patterns into coherent preferences
2. Resolve conflicts between different patterns
3. Prioritize preferences by frequency and recency
4. Format preferences for storage and use

### Phase 4: Integration and Application
1. Update user profile and configuration files
2. Adjust interaction guidelines and rules
3. Inform other skills and systems
4. Plan for future adaptation and learning

## Advanced Features

### Confidence Scoring
- **High confidence**: Explicit feedback, repeated patterns
- **Medium confidence**: Consistent but not explicit patterns
- **Low confidence**: Single occurrences, ambiguous signals
- **Tentative**: New patterns needing verification

### Preference Evolution Tracking
- Track how preferences change over time
- Detect learning and skill development
- Identify seasonal or project-based variations
- Predict future preference development

### Cross-User Pattern Analysis
- Compare patterns across different users (with permission)
- Identify common vs. unique preferences
- Learn from successful interaction patterns
- Improve default behaviors based on aggregate data

### Predictive Preference Modeling
- Predict user preferences for new situations
- Suggest optimizations based on similar users
- Anticipate needs before explicit requests
- Proactively adapt to changing contexts

## Safety and Privacy

### User Control
- Always allow users to review extracted preferences
- Provide opt-out for specific extraction types
- Allow manual correction of extracted preferences
- Support preference reset or deletion

### Data Minimization
- Only extract what's necessary for improvement
- Avoid sensitive or personal information
- Focus on interaction patterns, not content
- Regular cleanup of old extraction data

### Transparency
- Clearly explain what was extracted and why
- Show evidence for each extracted preference
- Provide confidence scores and reasoning
- Allow user to challenge or correct extractions

### Security
- Secure storage of extraction data
- Access controls for preference information
- Audit trails for extraction activities
- Compliance with privacy requirements

## Examples

### Example 1: Communication Style Extraction
```
Extracted: User prefers technical explanations with practical examples
Evidence:
- 5 instances of "Can you show me an example?"
- 3 corrections when explanations were too theoretical
- Positive feedback on code-heavy responses
- Faster task completion with example-based explanations
Confidence: High
Action: Update SOUL.md to prioritize practical examples
```

### Example 2: Workflow Preference Detection
```
Extracted: User likes detailed plans before complex tasks
Evidence:
- Always asks for "step-by-step plan" before major work
- Provides positive feedback on comprehensive planning
- Rejects quick-start approaches for complex tasks
- Success rate higher with detailed planning
Confidence: High
Action: Default to detailed planning for complex tasks
```

### Example 3: Tool Preference Learning
```
Extracted: Prefers Docker over manual environment setup
Evidence:
- 8 instances of choosing Docker solutions
- 2 corrections when non-Docker approach suggested
- Faster completion with containerized solutions
- Positive comments on Docker-based workflows
Confidence: Medium-High
Action: Suggest Docker solutions for environment tasks
```

## Integration Examples

### With Memory Review
```
Style Extractor provides preferences → Memory Review organizes them
Memory Review identifies pattern conflicts → Style Extractor resolves
Collaborative learning from historical interactions
```

### With Verification Gate
```
Style Extractor learns quality preferences → Verification Gate applies them
Verification outcomes feed back to improve preference accuracy
Personalized quality standards based on user style
```

### With Swarm Coordinator
```
Style Extractor provides user style → Swarm Coordinator tailors agent communication
Swarm results provide more style data → Style Extractor learns from them
Coordinated multi-agent interactions aligned with user preferences
```

## Best Practices

### Start Simple
- Begin with explicit feedback and clear patterns
- Gradually add more sophisticated detection
- Build confidence before making significant changes
- Validate extractions with user feedback

### Respect Boundaries
- Never extract without user awareness
- Always allow review and correction
- Focus on improving assistance, not surveillance
- Maintain clear separation from sensitive data

### Continuous Learning
- Regularly update extractions based on new interactions
- Re-evaluate confidence scores over time
- Archive outdated or no longer relevant preferences
- Adapt to changing user needs and contexts

### Balanced Approach
- Balance personalization with consistency
- Avoid over-fitting to temporary patterns
- Maintain core functionality while adapting style
- Provide options, not constraints

## Related Skills

- **memory-review** - Organizes and maintains extracted preferences
- **self-improving** - Learns from style-based interactions
- **context-compressor** - Adapts compression to user preferences
- **verification-gate** - Applies quality preferences to verification

## Development Roadmap

### Phase 1: Basic Extraction
- Explicit feedback analysis
- Simple pattern recognition
- Basic profile updates
- Manual review and approval

### Phase 2: Advanced Extraction
- Implicit preference detection
- Confidence scoring and validation
- Automated integration with other skills
- User preference dashboards

### Phase 3: Intelligent Extraction
- Predictive preference modeling
- Cross-user pattern learning
- Adaptive extraction strategies
- Seamless integration with all OpenClaw systems

## Inspiration

This skill is inspired by Claude Code's memory extraction system but expanded to cover a wider range of interaction styles and adapted for OpenClaw's diverse use cases beyond just coding assistance.