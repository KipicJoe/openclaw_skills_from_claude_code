---
name: Dream Memory
slug: dream-memory
version: 1.0.0
description: "Automatic memory consolidation and compression system for OpenClaw. Periodically reviews, organizes, and optimizes memory while preserving essential information."
metadata:
  openclaw:
    requires:
      bins: []
    os: ["linux", "darwin", "win32"]
    configPaths: ["./MEMORY.md", "./memory/", "./AGENTS.md", "./USER.md", "./SOUL.md", "./TOOLS.md"]
---

# Dream Memory - Automatic Memory Consolidation for OpenClaw

Background memory optimization system that automatically reviews, organizes, and compresses memory while preserving critical information and learning from patterns.

## When It Runs

Dream Memory operates automatically based on configurable triggers:

### Time-Based Triggers
- **Default**: Every 24 hours (configurable)
- **After heavy usage**: More frequent during active periods
- **Weekly deep clean**: Comprehensive weekly review
- **Monthly archive**: Long-term optimization and archiving

### Activity-Based Triggers
- **Session count**: After 5+ significant sessions (configurable)
- **Memory growth**: When memory files exceed size thresholds
- **Pattern accumulation**: When enough new patterns detected
- **User request**: Manual trigger for immediate consolidation

### Event-Based Triggers
- **Project completion**: After major tasks or projects
- **Context switching**: When moving between different work contexts
- **System maintenance**: During scheduled maintenance windows
- **Performance optimization**: When memory performance degrades

## Consolidation Process

### Phase 1: Memory Gathering
1. **Scan all memory layers**
   - MEMORY.md (long-term curated memory)
   - Daily memory files (recent session logs)
   - Self-improving memory (execution patterns)
   - Configuration files (preferences and rules)

2. **Collect activity metrics**
   - Session frequency and duration
   - Memory growth rates
   - Pattern emergence and evolution
   - User interaction statistics

### Phase 2: Pattern Analysis
1. **Identify significant patterns**
   - Recurring user requests and preferences
   - Successful workflows and approaches
   - Common errors and solutions
   - Evolving expertise and interests

2. **Detect memory issues**
   - Duplicate or redundant information
   - Outdated or contradictory entries
   - Unorganized or fragmented knowledge
   - Performance bottlenecks

### Phase 3: Consolidation Actions
1. **Promotion to long-term memory**
   - Significant lessons and decisions
   - Confirmed user preferences
   - Proven workflows and patterns
   - Important technical knowledge

2. **Compression and summarization**
   - Summarize detailed session logs
   - Compress similar entries
   - Remove transient information
   - Archive completed project details

3. **Organization and structuring**
   - Categorize related information
   - Create thematic sections
   - Establish cross-references
   - Improve navigability

4. **Cleanup and optimization**
   - Remove duplicates and redundancies
   - Archive old or irrelevant information
   - Optimize file sizes and structures
   - Update indexes and references

### Phase 4: Learning and Adaptation
1. **Extract learning insights**
   - Identify what information is most valuable
   - Learn optimal memory organization patterns
   - Understand user interaction preferences
   - Improve future consolidation strategies

2. **Update system knowledge**
   - Refine self-improving patterns
   - Update user profile with new insights
   - Adjust skill behaviors based on patterns
   - Optimize future interactions

## Gate System

Dream Memory uses a multi-gate system to determine when to run:

### 1. Time Gate (Primary)
- Minimum hours since last consolidation (default: 24)
- Prevents too-frequent consolidation
- Respects system and user activity patterns

### 2. Session Gate (Secondary)
- Minimum new sessions since last consolidation (default: 5)
- Ensures enough new material to justify consolidation
- Balances consolidation frequency with material volume

### 3. Resource Gate (Tertiary)
- System resource availability check
- Avoids consolidation during peak usage
- Respects user activity and system load

### 4. Priority Gate (Quaternary)
- Task and project completion triggers
- User request or manual trigger
- System maintenance windows

## Integration with Other Skills

### Memory Review Integration
- Dream Memory provides automated background consolidation
- Memory Review provides user-controlled detailed organization
- Together they maintain optimal memory health

### Context Compressor Integration
- Dream Memory identifies what to compress
- Context Compressor provides compression algorithms
- Integrated compression during consolidation

### Style Extractor Integration
- Dream Memory consolidation reveals new patterns
- Style Extractor analyzes and formalizes patterns
- Collaborative learning from memory evolution

### Self-Improving Integration
- Dream Memory identifies execution patterns
- Self-improving system learns from these patterns
- Continuous improvement of task execution

## Configuration Options

### Timing Configuration
```
dream-memory:
  min-hours: 24          # Minimum hours between runs
  min-sessions: 5        # Minimum new sessions
  max-daily-runs: 2      # Maximum runs per day
  preferred-times:       # Preferred run times
    - "02:00"
    - "14:00"
```

### Memory Layer Configuration
```
memory-layers:
  daily:
    keep-days: 30        # Keep daily files for 30 days
    compress-after: 7    # Compress files older than 7 days
    archive-after: 90    # Archive files older than 90 days
  long-term:
    max-size: "500KB"    # Maximum size for MEMORY.md
    target-size: "300KB" # Target size after consolidation
  self-improving:
    review-frequency: "weekly"  # How often to review
    pattern-threshold: 3        # Minimum occurrences for pattern
```

### Action Configuration
```
actions:
  promotion:
    confidence-threshold: 0.8   # Minimum confidence for promotion
    user-approval: "auto"       # auto, ask, or never
  compression:
    ratio: 0.5                  # Target compression ratio
    preserve-technical: true    # Preserve technical details
    preserve-user-feedback: true # Preserve user feedback
  cleanup:
    auto-delete: false          # Never auto-delete
    archive-instead: true       # Archive instead of delete
    review-before-archive: true # Review before archiving
```

## Usage Examples

### Automatic Operation
```
[Background process]
Dream Memory: Starting automatic consolidation...
- Time since last: 26 hours ✓
- New sessions: 7 ✓
- Memory growth: 1.2MB ✓

Processing:
- Scanned 42 daily memory files
- Identified 15 patterns for promotion
- Compressed 28 files (60% reduction)
- Archived 12 old files
- Updated MEMORY.md with 8 new entries

Consolidation complete. Memory optimized.
```

### Manual Trigger
```
User: /dream-memory run --full

Dream Memory: Starting full consolidation...
- Including all memory layers
- Deep pattern analysis
- Comprehensive optimization

Estimated time: 5-10 minutes
Progress: [=====>      ] 50%
...
Complete: Memory reduced by 45%, 23 patterns identified.
```

### Scheduled Operation
```
User: Schedule dream memory to run weekly

Dream Memory: Scheduled weekly consolidation:
- Every Sunday at 02:00
- Full memory review
- Pattern extraction and promotion
- Compression and cleanup
- Report generation

Added to cron schedule.
```

## Advanced Features

### Intelligent Pattern Recognition
- Machine learning for pattern detection
- Adaptive threshold adjustment
- Context-aware pattern evaluation
- Cross-session pattern correlation

### Predictive Consolidation
- Predict optimal consolidation timing
- Anticipate memory growth patterns
- Proactive optimization before issues
- Adaptive scheduling based on usage

### Quality Assurance
- Verification of consolidation results
- Backup before significant changes
- Rollback capability for issues
- Quality metrics and reporting

### User Feedback Integration
- Learn from user corrections
- Adapt consolidation based on feedback
- Improve pattern recognition accuracy
- Personalize consolidation strategies

## Safety Features

### Always Safe Operations
- Never delete without archiving first
- Always create backups before major changes
- Preserve original context when modifying
- Maintain audit trail of all changes

### User Control
- Configurable automation levels
- Manual approval for significant changes
- Ability to pause or disable automation
- Complete transparency about actions

### Error Handling
- Graceful failure recovery
- Automatic rollback on errors
- Detailed error reporting
- Safe continuation after issues

### Performance Protection
- Resource usage limits
- Background operation only
- Avoid interference with user tasks
- Optimized for minimal impact

## Integration Examples

### With Heartbeat System
```
HEARTBEAT.md addition:
## Dream Memory Check
- Check if dream memory should run
- Run if gates are open
- Report results to user
```

### With Notification System
```
After consolidation:
- Send summary report to user
- Notify of significant findings
- Alert about potential issues
- Provide optimization suggestions
```

### With Task System
```
After task completion:
- Trigger light consolidation
- Extract task patterns
- Update relevant memory
- Prepare for next task
```

## Best Practices

### Start Conservative
- Begin with less frequent consolidation
- Higher thresholds for pattern recognition
- Manual approval for significant changes
- Gradual automation as confidence grows

### Monitor Effectiveness
- Track memory performance metrics
- Measure user satisfaction with results
- Analyze consolidation impact on tasks
- Adjust configuration based on outcomes

### Maintain Balance
- Balance automation with user control
- Balance compression with information preservation
- Balance frequency with resource usage
- Balance pattern recognition with flexibility

### Continuous Improvement
- Learn from consolidation outcomes
- Adapt to changing user needs
- Incorporate new memory management techniques
- Evolve with OpenClaw system development

## Related Skills

- **memory-review** - Manual memory organization complement
- **context-compressor** - Compression algorithm provider
- **style-extractor** - Pattern analysis partner
- **kairos-lite** - Scheduling and trigger management

## Development Roadmap

### Phase 1: Basic Consolidation
- Time and session based triggering
- Basic pattern recognition
- Safe compression and organization
- Manual control and configuration

### Phase 2: Advanced Features
- Intelligent pattern detection
- Predictive consolidation
- Quality assurance systems
- Enhanced user feedback integration

### Phase 3: Intelligent System
- Machine learning optimization
- Seamless integration with all memory systems
- Adaptive personalization
- Proactive memory health management

## Inspiration

This skill is inspired by Claude Code's auto-dream system but expanded for OpenClaw's comprehensive memory ecosystem and adapted to handle diverse use cases beyond just coding sessions.