---
name: Swarm Coordinator
slug: swarm-coordinator
version: 1.0.0
description: "Multi-agent task coordination system for OpenClaw. Break large tasks into 4-phase multi-agent workflows with intelligent delegation and result synthesis."
metadata:
  openclaw:
    requires:
      bins: []
    os: ["linux", "darwin", "win32"]
    configPaths: []
---

# Swarm Coordinator - Multi-Agent Task Orchestration for OpenClaw

Coordinate multiple specialized agents to work together on complex tasks, breaking them into parallelizable phases with intelligent delegation.

## When to Use

- For large, complex tasks with multiple components
- When tasks require different areas of expertise
- For time-sensitive work that can be parallelized
- When tasks have clear phases or dependencies
- For projects requiring specialized knowledge in different domains

## The 4-Phase Swarm Workflow

### Phase 1: Analysis & Planning
**Coordinator Role**: Task understanding and decomposition
**Activities**:
- Analyze the complete task requirements
- Identify sub-tasks and dependencies
- Determine required expertise areas
- Plan parallel execution strategy
- Assign agents to specific roles

### Phase 2: Parallel Execution
**Coordinator Role**: Agent deployment and monitoring
**Activities**:
- Spawn specialized agents for each sub-task
- Provide clear instructions and context
- Monitor agent progress and status
- Handle inter-agent communication
- Manage resource allocation

### Phase 3: Synthesis & Integration
**Coordinator Role**: Result aggregation and conflict resolution
**Activities**:
- Collect results from all agents
- Identify conflicts or inconsistencies
- Resolve integration issues
- Combine partial solutions into coherent whole
- Validate combined results

### Phase 4: Verification & Delivery
**Coordinator Role**: Quality assurance and final delivery
**Activities**:
- Run comprehensive verification
- Ensure all requirements are met
- Prepare final deliverables
- Provide user with complete solution
- Document the process and results

## Agent Specialization Types

### 1. Research Agents
- Gather information and data
- Analyze requirements and constraints
- Explore solution alternatives
- Provide background context

### 2. Implementation Agents
- Write code and scripts
- Configure systems and services
- Create files and documentation
- Execute technical tasks

### 3. Verification Agents
- Test functionality and performance
- Validate correctness and completeness
- Check for errors and issues
- Ensure quality standards

### 4. Integration Agents
- Combine components and modules
- Resolve conflicts and dependencies
- Ensure interoperability
- Create cohesive solutions

### 5. Communication Agents
- Generate reports and documentation
- Create presentations and summaries
- Handle user communication
- Manage notifications and updates

## Coordination Patterns

### 1. Pipeline Pattern
```
Task → [Research] → [Implementation] → [Verification] → Result
```
Sequential processing with handoffs between specialized agents.

### 2. Parallel Pattern
```
          → [Agent A: Component 1]
Task →    → [Agent B: Component 2]  → [Integration] → Result
          → [Agent C: Component 3]
```
Parallel execution of independent components with final integration.

### 3. Hierarchical Pattern
```
Task → [Master Coordinator]
         ↓
    [Sub-Coordinator A] → [Worker A1, A2, A3]
    [Sub-Coordinator B] → [Worker B1, B2]
```
Multi-level coordination for very complex tasks.

### 4. Adaptive Pattern
```
Task → [Dynamic Allocation] → Adjust based on progress → Result
```
Flexible agent assignment based on real-time needs and progress.

## Usage Examples

### Basic Swarm Coordination
```
/swarm "Develop a web application with database backend"
/swarm --agents 4 "Complete system migration from old to new platform"
```

### Specialized Agent Assignment
```
/swarm --research 2 --implementation 3 --verification 1 "Create data pipeline"
/swarm --expertise "python,database,frontend" "Build full-stack application"
```

### Phase-Based Control
```
/swarm phase:planning "Analyze requirements for new feature"
/swarm phase:execution "Implement the planned components"
/swarm phase:integration "Combine all implemented parts"
/swarm phase:verification "Test complete solution"
```

## Coordinator Capabilities

### Intelligent Task Decomposition
- Analyze task complexity and requirements
- Identify natural breakpoints and dependencies
- Determine optimal parallelization strategy
- Assign appropriate agents to each component

### Agent Management
- Spawn agents with specific instructions and context
- Monitor agent status and progress
- Handle agent failures and retries
- Manage agent communication and coordination

### Result Synthesis
- Aggregate partial results from multiple agents
- Detect and resolve conflicts or inconsistencies
- Combine solutions into coherent whole
- Validate integrated results

### Communication Bridge
- Translate between user requirements and agent capabilities
- Provide user with consolidated progress updates
- Present final results in user-friendly format
- Handle user feedback and adjustments

## Integration with OpenClaw

### Existing Agent System
- Leverages OpenClaw's `sessions_spawn` for agent creation
- Uses `subagents` tool for agent management
- Integrates with `sessions_send` for inter-agent communication
- Utilizes `sessions_list` for status monitoring

### Skill Ecosystem
- Can delegate to other specialized skills
- Uses verification-gate for quality assurance
- Integrates with context-compressor for efficient communication
- Works with memory-review for knowledge sharing

### Task Management
- Creates structured task workflows
- Tracks progress across multiple agents
- Maintains task state and context
- Provides comprehensive task reporting

## Advanced Features

### Dynamic Agent Allocation
- Adjust number of agents based on task complexity
- Reallocate agents as priorities change
- Scale up/down based on progress and bottlenecks
- Optimize resource usage

### Learning Coordination
- Learn from successful coordination patterns
- Improve task decomposition strategies
- Optimize agent assignment based on past performance
- Adapt to user preferences and feedback

### Fault Tolerance
- Detect and handle agent failures
- Automatic retry with adjusted parameters
- Graceful degradation when agents unavailable
- Recovery strategies for partial failures

### Performance Optimization
- Parallel execution of independent tasks
- Efficient context sharing between agents
- Minimized communication overhead
- Optimized resource utilization

## Safety and Control

### User Oversight
- Always present coordination plan for approval
- Provide regular progress updates
- Allow user to adjust or stop coordination at any time
- Final approval before taking significant actions

### Resource Management
- Limit maximum concurrent agents
- Monitor system resource usage
- Prevent agent overload or conflicts
- Clean up agents after task completion

### Security Boundaries
- Respect permission boundaries for each agent
- Isolate agent access as appropriate
- Maintain security context separation
- Audit all agent actions

## Use Case Examples

### Complex System Administration
```
Task: Migrate entire infrastructure to new cloud provider
Swarm Coordination:
- Research Agent: Analyze current infrastructure and requirements
- Planning Agent: Design migration strategy and timeline
- Implementation Agent 1: Set up new cloud environment
- Implementation Agent 2: Migrate databases
- Implementation Agent 3: Migrate applications
- Verification Agent: Test everything works in new environment
- Integration Agent: Ensure all components work together
```

### Software Development Project
```
Task: Develop new feature with frontend, backend, and database changes
Swarm Coordination:
- Analysis Agent: Break down feature requirements
- Backend Agent: Implement API endpoints and business logic
- Frontend Agent: Create user interface components
- Database Agent: Design and implement schema changes
- Testing Agent: Write and run tests for all components
- Integration Agent: Ensure all parts work together
- Documentation Agent: Create user and technical documentation
```

### Data Analysis Pipeline
```
Task: Analyze large dataset and generate insights report
Swarm Coordination:
- Data Collection Agent: Gather and clean data from sources
- Analysis Agent 1: Statistical analysis
- Analysis Agent 2: Machine learning modeling
- Visualization Agent: Create charts and graphs
- Report Agent: Write comprehensive analysis report
- Quality Agent: Validate analysis methodology and results
```

## Best Practices

### Task Selection
- Use swarm coordination for truly complex tasks
- Ensure tasks have clear, measurable outcomes
- Verify tasks can be reasonably decomposed
- Consider time and resource constraints

### Agent Configuration
- Match agent expertise to task requirements
- Provide clear, specific instructions to each agent
- Establish communication protocols upfront
- Set expectations for deliverables and timelines

### Monitoring and Adjustment
- Regularly check agent progress and status
- Be prepared to adjust strategy based on results
- Handle conflicts or issues promptly
- Maintain overall task coherence

### Result Integration
- Plan integration strategy from the beginning
- Validate partial results as they arrive
- Resolve conflicts before final integration
- Test integrated solution thoroughly

## Related Skills

- **verification-gate** - For quality assurance of swarm results
- **context-compressor** - For efficient inter-agent communication
- **kairos-lite** - For scheduling swarm tasks
- **memory-review** - For knowledge sharing between agents

## Development Roadmap

### Phase 1: Basic Coordination
- Simple task decomposition
- Basic agent spawning and management
- Result collection and presentation

### Phase 2: Advanced Coordination
- Intelligent task analysis and planning
- Dynamic agent allocation
- Conflict detection and resolution
- Performance optimization

### Phase 3: Intelligent Coordination
- Learning from coordination patterns
- Predictive task decomposition
- Adaptive agent assignment
- Seamless integration with all OpenClaw systems

## Inspiration

This skill is inspired by Claude Code's coordinator system but adapted for OpenClaw's diverse agent capabilities and expanded to handle a wider range of task types beyond just software development.